
class RunnyStack<Base>
{

	private class Run{
		
		   
	    private Base object; // points to the object that appears in the run
	    private int length;   /// length of the run
	    private Run next;    // points to the instance of the run;( immediately below the stack)
		
	    
	    private Run(Base object, Run next)
		  {
		this.object = object;
		this.next = next;
		this.length=1;
		} 	  
	}
		    
private Run top;
private int depth;
private int runs;


public RunnyStack() {
	
	top = null;
	}


public int depth() {
	return depth;
	
}

public boolean isEmpty() {
	
	return top == null; //stack is empty
}

public Base peek() {
	
	if(isEmpty()) {
		throw new IllegalStateException("stack is empty");
		}
	return top.object;
}
	public void pop() 
	{
	
		if(isEmpty()) 
		{
			throw new IllegalStateException("stack is empty");
		}
		else {
		  
		  top.length--;
		  depth--;
		  
		    }
		   if(top.length==0) {
		    top=top.next;
		    runs--;
		   }
	}

	public void push(Base object) {
		depth++;
		if(isEmpty()) {
			
				
			top = new Run(object, top);
			 runs++; 
			}
		
		else if (isEqual(object)) {
		
		top.length++;
		
		
		}
		else {
			top = new Run(object, top);
			 runs++; 
			 
		}
	}	
					
	
    public boolean isEqual(Base object) {
    	if(top.object==null || object==null) {
    	
    	return top.object==object;
    }
    	else {
    		return object.equals(top.object);
    		
    	}
    }
	
     public int runs() {
    	 if(isEmpty()) {
    		 return 0;
    	 }
    	 return runs;
     }

}

/*outputs
 true
0
0
No pop
No peek
A
1
1
false
B
2
2
B
3
2
B
4
2
C
5
3
C
6
3
C
5
3
B
4
2
B
3
2
A
1
1
true
0
0
No peek
*/
