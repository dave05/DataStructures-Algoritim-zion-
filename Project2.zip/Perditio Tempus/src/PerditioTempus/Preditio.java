package PerditioTempus;

public class Preditio {

	public static void main(String[] args) {
		Tableau newPlay = new Tableau();
		newPlay.play();
		// TODO Auto-generated method stub

	}

}
