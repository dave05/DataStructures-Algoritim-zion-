package PerditioTempus;

public class Pile {
	private Layer top;
	private class Layer
	{
		Card card;
		Layer next;
	
		
	public Layer(Card card, Layer next)
	{
		this.card=card;
		this.next=next;
	}
	
	}
	public Pile()
	{
		this.top=new Layer(null,null);
	}
	public void add(Card card)
	{
		Layer nlayer = new Layer(card,top);
		this.top=nlayer;
	}
	public Card turn()
	{
		if(isEmpty())
		{
			throw new IllegalStateException();
		}
		else
		{
			Card temp = top.card;
			top= top.next;
			return temp;
		}
	}
	public boolean isEmpty()
	{
		return this.top==null;
	}

}
