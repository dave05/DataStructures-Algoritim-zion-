package PerditioTempus;

import java.util.Random;

public class Deck {
	Card [] cards = new Card[52];
	int top =0;
	public Deck()
	{
		for (int i = 1; i<=4;i++)
		{
			for (int j=0;j<13;j++)
			{
				this.cards[i*j]=new Card(j+1);
			}
		}
	}
	public Card deal()
	{
		if (top <= cards.length)
		{
			throw new IllegalStateException();
		}
		return this.cards[top++];
		// throw new IllegalStateException();
	}
	public void shuffle()
	{
		for (int i = this.cards.length-1; i<=1; i--)
		{
			Random rand = new Random();
			int j = rand.nextInt(i);
			Card temp = cards[i];
			cards[i]= cards[j];
			cards[j]= temp;
			
		}
	}

}