package PerditioTempus;

public class Tableau {
	private Pile[] piles = new Pile[13];
	public Tableau()
	{
		Deck nDeck = new Deck();
		nDeck.shuffle();
		for (int i = 1; i<=piles.length;i++)
		{
			if(nDeck.top!=0)
			{
				this.piles[i] = new Pile();
				this.piles[i].add(nDeck.deal());
				this.piles[i].add(nDeck.deal());
				this.piles[i].add(nDeck.deal());
				this.piles[i].add(nDeck.deal());
				
			}
		}
	}
	private boolean hasWon()
	{
		boolean flag = true ;
		for (int i = 0; i<piles.length;i++)
		{
			if(!piles[i].isEmpty())
			{
				flag = false;
			}
			
		}
		return flag;
	}
	public void play()
	{
		int p = 1;
		while(!this.piles[p].isEmpty())
		{
		Card current = piles[p].turn();
		System.out.println("Get" + current.toString()+" From Pile "+ p);
		p = current.getRank();
	}
		if(hasWon())
		{
			System.out.println("You Won!");
			
		}
		else
		{
			System.out.println("pile "+p+" is Empty. You Lost!");
		}

}
}